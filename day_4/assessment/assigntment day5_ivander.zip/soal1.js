for(let i = 1; i<=20;i++) {
    if(i%2===0) {
        console.log(`${i} merupakan bilangan genap`);
    } else {
        console.log(`${i} merupakan bilangan ganjil`);
    }
    if(i%4===0) {
        console.log(`${i} habis dibagi dengan 4`)
    } else if(i%6===0) {
        console.log(`${i} habis dibagi dengan 6`)
    } else if(i%4===0 && i%6===0) {
        console.log(`${i} habis dibagi dengan 4 dan 6`)
    } else {
        console.log(`${i}`)
    }
    if(i%3===0 || i%5===0) {
        console.log(`${i} habis dibagi dengan 3 atau 5`)
    } else {
        console.log(`bilangan ${i} tidak habis dibagi 3 dan 5`)
    }
    console.log("===================")
}