for(let nilai=1;nilai<=5;nilai++){
    for(let pangkat=1; pangkat<=3;pangkat++) {
        console.log(`${nilai} pangkat ${pangkat} = ${nilai**pangkat}`)
    }
    console.log("===============================")
}